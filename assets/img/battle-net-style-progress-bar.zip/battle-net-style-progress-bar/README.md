# Battle.net Style Progress Bar

A Pen created on CodePen.io. Original URL: [https://codepen.io/simeydotme/pen/abPxRE](https://codepen.io/simeydotme/pen/abPxRE).

A progress bar with a style very similar to the battle.net one... I couldn't get the borders to have animated pulse, though :(